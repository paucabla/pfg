# MEANie

MEANie - MEAN Stack CMS & Blogging Platform

For documentation and further details go to http://jasonwatmore.com/meanie
